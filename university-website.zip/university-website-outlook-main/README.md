# university-website-outlook
Hey guys....!<br>
This is my own University website out look ,Just done as mini project as i am bored...but it looked great.
1.use index.html to run the website.<br>
<b>#Hope u like the project.<br>
#Feel free to download the source code and follow for new projects.<br>
#dont foget to give a star if u like the project.<br>
Demo video
link:https://reddys-university-website.herokuapp.com/</b>
